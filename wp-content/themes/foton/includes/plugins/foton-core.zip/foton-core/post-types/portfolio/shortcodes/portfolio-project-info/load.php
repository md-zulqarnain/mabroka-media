<?php

require_once 'portfolio-project-info.php';
require_once 'helper-functions.php';

if ( foton_mikado_is_elementor_installed() ) {
	require_once 'elementor-portfolio-project-info.php';
}