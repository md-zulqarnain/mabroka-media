<?php

include_once FOTON_CORE_SHORTCODES_PATH . '/image-gallery/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/image-gallery/image-gallery.php';