<?php

include_once FOTON_CORE_SHORTCODES_PATH . '/floating-images/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/floating-images/floating-images.php';