<?php

include_once FOTON_CORE_SHORTCODES_PATH . '/cards-gallery/functions.php';
include_once FOTON_CORE_SHORTCODES_PATH . '/cards-gallery/cards-gallery.php';